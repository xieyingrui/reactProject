module.exports = {
	publicPath:"./",
  	devServer: {
 	   proxy: 'http://localhost:3000'
  	}
}