<template>
	<div>
		<router-link to='/list/123'>123</router-link>
	   	<router-link to='/list/456'>456</router-link>
	   	<router-link to='/list/789'>789</router-link>

	   	<router-view></router-view>	
	</div>
</template>