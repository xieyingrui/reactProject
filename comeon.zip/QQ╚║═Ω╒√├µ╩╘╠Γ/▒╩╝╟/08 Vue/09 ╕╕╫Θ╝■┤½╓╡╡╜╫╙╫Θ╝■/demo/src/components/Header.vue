<template>
	<div>
		子组件

		<hr />

		{{msg}}


	</div>
</template>

<script type="text/javascript">
export default {
	//props:['msg']
	props:{
		msg:String
	}
}
</script>