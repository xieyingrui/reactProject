<template>
  <div class="home">
  	<h1>首页</h1>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
<style scoped>
h1{
	background: red;
}
</style>
